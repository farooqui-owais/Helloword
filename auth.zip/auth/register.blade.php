<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.101.0">
    <title>Register Page</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/4.6/examples/sign-in/">
    <link rel="stylesheet" type="text/css" href="/assets/dist/css/bootstrap.min.css">    
    <!-- Custom styles for this template -->
    <link href="/assets/dist/css/signin.css" rel="stylesheet">
  </head>
<div class="container">
<div class="row">
<div class="col-md-4 order-md-2 mb-4"></div>
    <div class="col-md-8 order-md-1">
            
            
            <form class="needs-validation" novalidate="" class="" action="/api/register" method="post">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="salutations">Salutations</label>
                            <select  class="form-control" name="salutations" id="salutations">
                                <option value="0">Mr</option>
                                <option value="1">Mrs</option>
                                <option value="2">Miss</option>
                            </select>
                        
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="fullname">Full Name</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="" value="" required="">
                            <div class="invalid-feedback">
                                Valid  name is required.
                            </div>
                        </div>
                    </div>

                        <div class="mb-3">
                            <label for="email">Email </label>
                            <input type="email" class="form-control"  name="email" id="email" placeholder="you@example.com">
                            <div class="invalid-feedback">
                                Please enter a valid email address for shipping updates.
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="address">Address</label>
                            <input type="text" class="form-control" name="address" id="address" placeholder="" required="">
                            <div class="invalid-feedback">
                                Please enter your shipping address.
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="phone">Phone </label>
                            <input type="text" class="form-control" name="phone_no" id="phone_no" placeholder="">
                            <div class="invalid-feedback">
                                Please enter a valid Phone Number.
                            </div>
                        </div>  

                        <div class="mb-3">
                            <label for="address">Date Of Birth</label>
                            <input type="date" class="form-control" name="dob" id="dob" placeholder="" required="">
                            <div class="invalid-feedback">
                            Please enter Your Date of Birth.
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="password">Password</label>
                            <input type="password" class="form-control"name="password" id="password" placeholder="" required="">
                            <div class="invalid-feedback">
                            Please enter Password.
                            </div>
                        </div>

                    <button type="submit" class="btn btn-success">Submit</button>
                </form>
        </div> 
    </div>
</div>            
</body>
</html>
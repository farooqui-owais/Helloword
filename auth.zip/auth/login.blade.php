<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.101.0">
    <title>Signin Page</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/4.6/examples/sign-in/">
    <link rel="stylesheet" type="text/css" href="/assets/dist/css/bootstrap.min.css">    
    <!-- Custom styles for this template -->
    <link href="/assets/dist/css/signin.css" rel="stylesheet">
  </head>
<body>
<div class="container" style="margin-top:20px;">
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">Login</div>
            <div class="panel-body">
            
                <form action="/api/login" method="post" accept-charset="utf-8"  class="form-signin">
                    
                    <h1 class="h3 mb-6 font-weight-normal">Please sign in</h1>
                    
                        <div class="row">
                        <div class="col-md-12">
                            <label for="inputEmail">Email address</label>
                            <input type="email" class="form-control" name="email" id="email">                 
                        </div>
                        <div class="col-md-12">
                            <label for="fullname">Password</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="" value="" required="">
                            <div class="invalid-feedback">
                                Valid  name is required.
                            </div>
                        </div>
                    </div>
                        <div class="checkbox mb-3">
                            <label>
                                 <input type="checkbox" value="remember-me"> Remember me
                            </label>
                            </div>
                        <button class="btn btn-lg purple btn-block" type="submit">Sign in</button>
                         <p class="mt-5 mb-3 text-muted">&copy; 2022</p>
                </form>
            </div>
        </div>
    </div>
</div>  
</body>
</html>